#pragma once
#include <Arduino.h>
#include "Ultrasonic.h"

/*
 * =====================================================================================
 * Class: StartTrigger (Hands-free start)
 * Starts a run when both side sensors are covered for 5 seconds.
 * =====================================================================================
 */
class StartTrigger {
private:
    Ultrasonic&   _leftSensor;
    Ultrasonic&   _rightSensor;
    unsigned long _holdStartMs;
    bool          _isHolding;

    const float   TRIGGER_DISTANCE_CM = 5.0;
    const float   MIN_DISTANCE_CM     = 1.0;
    const unsigned long HOLD_TIME_MS  = 5000; // 5 seconds hold

    // Checks whether an object (e.g. hand) is held within 5 cm of the sensor
    bool isClose(float distanceCm) {
        return distanceCm > MIN_DISTANCE_CM && distanceCm < TRIGGER_DISTANCE_CM;
    }

public:
    StartTrigger(Ultrasonic& leftSensor, Ultrasonic& rightSensor)
        : _leftSensor(leftSensor), _rightSensor(rightSensor),
          _holdStartMs(0), _isHolding(false) {}

    // Checks continuously if the hold time has passed
    bool isTriggered() {
        bool isCovered = isClose(_leftSensor.getDistanceCm()) &&
                         isClose(_rightSensor.getDistanceCm());

        if (!isCovered) {
            _isHolding = false;
            return false;
        }
        if (!_isHolding) {
            _isHolding = true;
            _holdStartMs = millis();
        }
        if (millis() - _holdStartMs >= HOLD_TIME_MS) {
            _isHolding = false;
            return true;
        }
        return false;
    }

    // Blocks execution until both side sensors are held for 5 seconds
    // (no delay needed: reading the sensors already takes some time)
    void waitForStart() {
        while (!isTriggered()) {}
    }
};
