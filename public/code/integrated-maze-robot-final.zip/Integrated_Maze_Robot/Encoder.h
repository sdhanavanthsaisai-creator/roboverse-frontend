#pragma once
#include <Arduino.h>

class Encoder {
private:
    int _pinA;
    int _pinB;
    volatile long _ticks;
    bool _isReversed;      // flips the counting direction for a mirrored wheel

    // Interrupt handler: runs on every rising edge of channel A
    static void IRAM_ATTR isrHandler(void* arg) {
        Encoder* self = static_cast<Encoder*>(arg);

        // Channel B decides the direction
        bool isForward = (digitalRead(self->_pinB) == HIGH);
        if (self->_isReversed) {
            isForward = !isForward;
        }

        if (isForward) {
            self->_ticks++;
        } else {
            self->_ticks--;
        }
    }

public:
    Encoder(int pinA, int pinB, bool isReversed = false)
        : _pinA(pinA), _pinB(pinB), _ticks(0), _isReversed(isReversed) {}

    void begin() {
        pinMode(_pinA, INPUT_PULLUP);   // no effect on pins 34-39: add external pull-ups if counts are noisy
        pinMode(_pinB, INPUT_PULLUP);

        attachInterruptArg(
            digitalPinToInterrupt(_pinA),
            isrHandler,
            this,
            RISING
        );

        reset();
    }

    // Positive = forward, negative = backward
    long getTicks() {
        return _ticks;
    }

    void reset() {
        _ticks = 0;
    }
};
