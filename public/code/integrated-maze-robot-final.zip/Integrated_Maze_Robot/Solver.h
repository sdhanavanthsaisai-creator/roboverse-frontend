#pragma once

/*
 * =====================================================================================
 * Class: Solver
 * Abstract interface for all maze-solving algorithms
 * =====================================================================================
 */

// The four fundamental navigation decisions at any cell
enum Move {
    MOVE_LEFT,
    MOVE_STRAIGHT,
    MOVE_RIGHT,
    MOVE_BACK
};

class Solver {
public:
    virtual ~Solver() {}   // lets the right cleanup run for child classes

    // Decides the next move based on wall detections around the robot
    virtual Move chooseMove(bool hasLeftWall, bool hasFrontWall, bool hasRightWall) = 0;
};
