#pragma once

#include <Wire.h>
#include <MPU6050_tockn.h>
#include "pins.h"          // for IMU_YAW_SIGN

class Imu {
public:
    Imu() : _mpu(Wire) {}

    void begin() {
        Wire.begin(21, 22);            // I2C: SDA = 21, SCL = 22
        _mpu.begin();
        _mpu.calcGyroOffsets(true);    // calibration: keep the robot still
    }

    void update() {
        _mpu.update();
    }

    // Angle turned around the vertical axis, in degrees.
    // Positive = left turn (set IMU_YAW_SIGN in pins.h if it is the other way round).
    float getYawDeg() {
        return IMU_YAW_SIGN * _mpu.getAngleZ();
    }

private:
    MPU6050 _mpu;
};
