# Maze Robot (final integrated sketch)

Arduino IDE sketch for the ESP32. Open `Integrated_Maze_Robot.ino`; all other files are in the same folder.

## Files

- Integrated_Maze_Robot.ino (state machine: RUN_1, WAITING, RUN_2, FINISHED, FAILED)
- pins.h (all pins, wall threshold, reverse flags, gyro sign)
- Motor.h, Encoder.h, Ultrasonic.h, Imu.h (hardware)
- Robot.h (moveOneCell, turnLeft, turnRight, turnAround)
- Solver.h, WallFollower.h (left-hand rule)
- PathRecorder.h (records Run 1 and removes dead ends)
- MazeRunner.h (Run 1), PathReplayer.h (Run 2), StartTrigger.h (start by covering both side sensors for 5 s)

## How a run works

1. Power on, keep the robot still while the IMU calibrates.
2. Cover both side sensors (under 5 cm) for 5 seconds. Take your hands away after the 3 second pause.
3. Run 1: wall following, saves junctions and dead ends, stops when the front sensor reads 350 cm or more (3 readings in a row).
4. Put the robot back at the start (do NOT switch it off) and cover both side sensors for 5 seconds.
5. Run 2: replays the shortened path at a higher speed.

## Changes from the test branch

- `WALL_THRESHOLD_CM` is now defined in `pins.h` (it was missing, so the sketch did not compile).
- The three ultrasonic sensors are started in `setup()`.
- Run 1 now waits for the start trigger.
- Reverse flags for the mirrored motor and encoder are in `pins.h`.
- The heading correction sign was fixed, and `IMU_YAW_SIGN` in `pins.h` flips turns and steering together if needed.
- `moveOneCell()` and `turnBy()` stop after a time limit; the robot then enters the FAILED state.
- The goal needs 3 front readings in a row of 350 cm or more.
- Front ultrasonic TRIG moved from GPIO12 to GPIO4 (rewire!).
- Start trigger is 5 cm for 5 seconds, Run 2 speed is 150.

## Calibration (do these on the robot)

1. `Robot.h` -> `TICKS_PER_CELL` (push the robot exactly 50 cm and read the ticks)
2. `pins.h` -> reverse flags (each wheel must drive forward, each encoder must count up)
3. `pins.h` -> `IMU_YAW_SIGN` (turning left must increase the yaw)
4. `pins.h` -> `WALL_THRESHOLD_CM`
5. `Robot.h` -> turn speeds, `HEADING_KP`
6. `PathReplayer.h` -> Run 2 speed, only if needed

## Hardware checks

- Use a voltage divider on every ultrasonic ECHO pin (5 V to 3.3 V).
- GPIO 34-39 have no internal pull-up: add external pull-ups to the encoder lines if the counts are noisy.
- Share a common ground between the motor driver, the ESP32 and the sensors.
- Set the XL4005 buck converter to 5 V before connecting the ESP32.
