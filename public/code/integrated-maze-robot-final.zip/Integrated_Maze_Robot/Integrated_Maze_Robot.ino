#include "pins.h"
#include "Motor.h"
#include "Encoder.h"
#include "Ultrasonic.h"
#include "Imu.h"
#include "Solver.h"
#include "WallFollower.h"
#include "PathRecorder.h"
#include "Robot.h"
#include "MazeRunner.h"
#include "PathReplayer.h"
#include "StartTrigger.h"

// Motors: the "reversed" flags are set in pins.h (one side of the robot is mirrored)
Motor leftMotor(LEFT_MOTOR_PWM_PIN, LEFT_MOTOR_DIR_PIN, LEFT_MOTOR_REVERSED);
Motor rightMotor(RIGHT_MOTOR_PWM_PIN, RIGHT_MOTOR_DIR_PIN, RIGHT_MOTOR_REVERSED);

Encoder leftEncoder(LEFT_ENCODER_PIN_A, LEFT_ENCODER_PIN_B, LEFT_ENCODER_REVERSED);
Encoder rightEncoder(RIGHT_ENCODER_PIN_A, RIGHT_ENCODER_PIN_B, RIGHT_ENCODER_REVERSED);

Ultrasonic frontUltrasonic(FRONT_ULTRASONIC_TRIG_PIN, FRONT_ULTRASONIC_ECHO_PIN);
Ultrasonic leftUltrasonic(LEFT_ULTRASONIC_TRIG_PIN, LEFT_ULTRASONIC_ECHO_PIN);
Ultrasonic rightUltrasonic(RIGHT_ULTRASONIC_TRIG_PIN, RIGHT_ULTRASONIC_ECHO_PIN);

Imu imu;

Robot robot(leftMotor, rightMotor, leftEncoder, rightEncoder, imu);

WallFollower solver;
PathRecorder path;

MazeRunner runner(
    robot,
    solver,
    path,
    leftUltrasonic,
    frontUltrasonic,
    rightUltrasonic
);

PathReplayer replayer(
    robot,
    solver,
    path,
    leftUltrasonic,
    frontUltrasonic,
    rightUltrasonic
);

StartTrigger trigger(leftUltrasonic, rightUltrasonic);

enum MazeState {
    RUN_1,
    WAITING,
    RUN_2,
    FINISHED,
    FAILED
};

MazeState currentState = RUN_1;

void setup() {
    Serial.begin(115200);
    delay(1000);

    // The ultrasonic sensors must be started before they are used.
    frontUltrasonic.begin();
    leftUltrasonic.begin();
    rightUltrasonic.begin();

    // Starts motors, encoders and the IMU (the IMU calibrates: keep the robot still).
    robot.begin();
    robot.setMoveSpeed(120);

    Serial.println("Maze Robot Ready");
    Serial.println("Cover both side sensors for 5 seconds to start Run 1");

    trigger.waitForStart();

    Serial.println("Starting in 3 seconds, take your hands away");
    delay(3000);   // so hands are not read as walls
    Serial.println("Run 1 started");
}

void loop() {
    // Safety: if a move or turn timed out, stop for good.
    if (robot.hasFailed()) {
        robot.stop();
        if (currentState != FAILED) {
            Serial.println("Robot stopped: a move or turn timed out. Check wiring and restart.");
            currentState = FAILED;
        }
        delay(500);
        return;
    }

    if (currentState == RUN_1) {
        runner.step();

        if (runner.isFinished()) {
            robot.stop();
            Serial.println("Goal reached.");
            Serial.print("Saved moves: ");
            Serial.println(path.size());

            Serial.println("Put the robot back at the start, then cover both side sensors for 5 seconds");
            currentState = WAITING;
        }

        delay(100);
    }

    else if (currentState == WAITING) {
        robot.stop();

        if (trigger.isTriggered()) {
            Serial.println("Starting in 3 seconds, take your hands away");
            delay(3000);   // so hands are not read as walls
            replayer.start();
            currentState = RUN_2;
            Serial.println("Run 2 started");
        }

        delay(100);
    }

    else if (currentState == RUN_2) {
        replayer.step();

        if (replayer.isFinished()) {
            robot.stop();
            Serial.println("Run 2 finished.");
            currentState = FINISHED;
        }

        delay(100);
    }

    else if (currentState == FINISHED) {
        robot.stop();
        delay(500);
    }
}
