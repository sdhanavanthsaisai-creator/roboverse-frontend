#pragma once
#include "Solver.h"

/*
 * =====================================================================================
 * Class: PathRecorder (Coder 2 - Friend's Module)
 * Records Attempt 1 moves and simplifies out dead ends for Attempt 2
 * =====================================================================================
 */
class PathRecorder {
private:
    static const int MAX_MOVES = 100;
    Move _moves[MAX_MOVES];
    int _count;

    // Combines move before a dead end and move after into a direct shortcut
    Move combine(Move before, Move after) {
        if (before == MOVE_LEFT     && after == MOVE_LEFT)     return MOVE_STRAIGHT;
        if (before == MOVE_LEFT     && after == MOVE_STRAIGHT) return MOVE_RIGHT;
        if (before == MOVE_LEFT     && after == MOVE_RIGHT)    return MOVE_BACK;
        if (before == MOVE_STRAIGHT && after == MOVE_LEFT)     return MOVE_RIGHT;
        if (before == MOVE_STRAIGHT && after == MOVE_STRAIGHT) return MOVE_BACK;
        if (before == MOVE_RIGHT    && after == MOVE_LEFT)     return MOVE_BACK;
        return MOVE_BACK;
    }

    // Shifts subsequent moves left by 2 positions to delete the pruned dead end
    void removeTwo(int index) {
        for (int k = index; k + 2 < _count; k++) {
            _moves[k] = _moves[k + 2];
        }
        _count -= 2;
    }

public:
    // Initializes empty path recorder
    PathRecorder() : _count(0) {}

    // Appends a move to the recorded path history
    void record(Move move) {
        if (_count < MAX_MOVES) {
            _moves[_count] = move;
            _count++;
        }
    }

    // Returns the number of currently saved moves
    int size() {
        return _count;
    }

    // Returns the saved move at a given index
    Move get(int index) {
        return _moves[index];
    }

    // Iteratively removes dead ends (U-turns) until only the optimal route remains
    void simplify() {
        bool changed = true;
        while (changed) {
            changed = false;
            for (int i = 1; i < _count - 1; i++) {
                if (_moves[i] == MOVE_BACK) {
                    _moves[i - 1] = combine(_moves[i - 1], _moves[i + 1]);
                    removeTwo(i);
                    changed = true;
                    break;
                }
            }
        }
    }
};
