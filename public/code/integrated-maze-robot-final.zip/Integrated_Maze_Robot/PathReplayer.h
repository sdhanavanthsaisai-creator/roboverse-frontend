#pragma once
#include <Arduino.h>
#include "Robot.h"
#include "Ultrasonic.h"
#include "Solver.h"
#include "PathRecorder.h"
#include "pins.h"

/*
 * =====================================================================================
 * Class: PathReplayer (Run 2: Optimized High-Speed Replay)
 * 
 * Logic from teammate's PathReplayer:
 *   - Replays the shortened pruned path from Run 1 at higher speed.
 *   - Follows saved moves at junctions (openSides >= 2).
 *   - Has dynamic obstacle fallback: if a saved move is blocked by an unexpected dynamic
 *     obstacle, it smoothly falls back to the WallFollower rule to keep navigating!
 * =====================================================================================
 */
class PathReplayer {
private:
    Robot&        _robot;
    Solver&       _solver;
    PathRecorder& _path;
    Ultrasonic&   _leftSensor;
    Ultrasonic&   _frontSensor;
    Ultrasonic&   _rightSensor;
    int           _nextIndex;
    bool          _isFinished;
    bool          _isFallback;

    // CALIBRATION: must match the wall detection used during Run 1.
    const float   WALL_DISTANCE_CM = WALL_THRESHOLD_CM;

    // CALIBRATION: distance used to recognize the open goal/exit area.
    const float   GOAL_DISTANCE_CM = 350.0;

    // CALIBRATION: Run 2 speed. Lower this if the robot overshoots or becomes unstable.
    const int     FAST_MOVE_SPEED  = 150;

    // The goal counts only if 3 front readings in a row agree.
    // One bad reading (no echo gives 400) cannot end the run by mistake.
    bool isGoalConfirmed() {
        for (int i = 0; i < 3; i++) {
            if (_frontSensor.getDistanceCm() < GOAL_DISTANCE_CM) return false;
        }
        return true;
    }

    // Checks if the planned move direction is blocked by a wall or obstacle
    bool isBlocked(Move move, bool hasLeftWall, bool hasFrontWall, bool hasRightWall) {
        if (move == MOVE_LEFT)     return hasLeftWall;
        if (move == MOVE_STRAIGHT) return hasFrontWall;
        if (move == MOVE_RIGHT)    return hasRightWall;
        return false;
    }

    // Turns if needed, then drives one 50 cm cell.
    void doMove(Move move) {
        if (move == MOVE_LEFT)  _robot.turnLeft();
        if (move == MOVE_RIGHT) _robot.turnRight();
        if (move == MOVE_BACK)  _robot.turnAround();
        _robot.moveOneCell();
    }

public:
    // Initializes the speed run replayer
    PathReplayer(Robot& robot, Solver& solver, PathRecorder& path,
                 Ultrasonic& leftSensor, Ultrasonic& frontSensor, Ultrasonic& rightSensor)
        : _robot(robot), _solver(solver), _path(path),
          _leftSensor(leftSensor), _frontSensor(frontSensor), _rightSensor(rightSensor),
          _nextIndex(0), _isFinished(false), _isFallback(false) {}

    // Configures the robot for high-speed Run 2 execution
    void start() {
        _robot.setMoveSpeed(FAST_MOVE_SPEED);
        _nextIndex = 0;
        _isFinished = false;
        _isFallback = false;
    }

    // Returns true once the goal/exit has been reached on Run 2
    bool isFinished() {
        return _isFinished;
    }

    // Executes one speed-run step: call continuously from loop()
    void step() {
        if (_isFinished) return;

        float frontCm = _frontSensor.getDistanceCm();
        if (frontCm >= GOAL_DISTANCE_CM && isGoalConfirmed()) { // Goal/exit detected (3 readings agree).
            _robot.stop();
            _isFinished = true;
            return;
        }

        bool hasLeftWall  = _leftSensor.getDistanceCm()  < WALL_DISTANCE_CM;
        bool hasFrontWall = frontCm                      < WALL_DISTANCE_CM;
        bool hasRightWall = _rightSensor.getDistanceCm() < WALL_DISTANCE_CM;

        int openSides = 0;
        if (!hasLeftWall)  openSides++;
        if (!hasFrontWall) openSides++;
        if (!hasRightWall) openSides++;

        Move move;
        // At junctions: replay saved pruned move
        if (!_isFallback && openSides >= 2 && _nextIndex < _path.size()) {
            move = _path.get(_nextIndex);
            if (isBlocked(move, hasLeftWall, hasFrontWall, hasRightWall)) {
                _isFallback = true; // Dynamic obstacle detected -> switch to WallFollower!
                move = _solver.chooseMove(hasLeftWall, hasFrontWall, hasRightWall);
            } else {
                _nextIndex++;
            }
        } else {
            // In a corridor or fallback mode: follow normal rule
            move = _solver.chooseMove(hasLeftWall, hasFrontWall, hasRightWall);
        }

        doMove(move);
    }
};
