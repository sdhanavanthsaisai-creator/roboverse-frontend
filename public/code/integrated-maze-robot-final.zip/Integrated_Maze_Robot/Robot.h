#pragma once

#include <Arduino.h>
#include <math.h>
#include "Motor.h"
#include "Encoder.h"
#include "Imu.h"

// CALIBRATION: tune the values at the bottom of this file on the actual robot.
class Robot {
public:
    Robot(Motor& leftMotor, Motor& rightMotor,
          Encoder& leftEncoder, Encoder& rightEncoder,
          Imu& imu)
        : _leftMotor(leftMotor),
          _rightMotor(rightMotor),
          _leftEncoder(leftEncoder),
          _rightEncoder(rightEncoder),
          _imu(imu) {}

    void begin() {
        _leftMotor.begin();
        _rightMotor.begin();
        _leftEncoder.begin();
        _rightEncoder.begin();
        _imu.begin();
        stop();
    }

    // DO NOT RENAME: used by MazeRunner and PathReplayer.
    void stop() {
        _leftMotor.stop();
        _rightMotor.stop();
    }

    // Set forward movement speed: 0-255.
    void setMoveSpeed(int speed) {
        _moveSpeed = constrain(speed, 0, 255);
    }

    // True if a move or turn took too long (encoder, gyro or motor problem).
    // Once true, the robot refuses to move until it is restarted.
    bool hasFailed() {
        return _hasFailed;
    }

    // Drives forward one cell. The encoders measure the distance and the gyro keeps it straight.
    // CALIBRATION: measure encoder ticks for exactly one maze cell (50 cm).
    void moveOneCell() {
        if (_hasFailed) return;

        _leftEncoder.reset();
        _rightEncoder.reset();

        _imu.update();
        float targetYaw = _imu.getYawDeg();      // heading to hold
        unsigned long startMs = millis();

        while (averageTicks() < TICKS_PER_CELL) {
            if (millis() - startMs > MOVE_TIMEOUT_MS) {
                fail("Move timeout");
                return;
            }

            _imu.update();

            // Drifting left makes the yaw rise, so the error is negative:
            // the left wheel speeds up and the right wheel slows down, steering back right.
            float headingError = targetYaw - _imu.getYawDeg();
            int correction = constrain((int)(headingError * HEADING_KP), -HEADING_LIMIT, HEADING_LIMIT);

            int leftSpeed = _moveSpeed - correction;
            int rightSpeed = _moveSpeed + correction;

            _leftMotor.forward(leftSpeed);
            _rightMotor.forward(rightSpeed);
        }

        stop();
    }

    // DO NOT RENAME: used by MazeRunner and PathReplayer.
    void turnLeft() {
        turnBy(90);
    }

    // DO NOT RENAME: used by MazeRunner and PathReplayer.
    void turnRight() {
        turnBy(-90);
    }

    // DO NOT RENAME: used by MazeRunner and PathReplayer.
    void turnAround() {
        turnBy(180);
    }

private:
    long averageTicks() {
        return (_leftEncoder.getTicks() + _rightEncoder.getTicks()) / 2;
    }

    // Stops everything and remembers that something went wrong.
    void fail(const char* message) {
        stop();
        _hasFailed = true;
        Serial.println(message);
    }

    // Spins in place until the gyro says we have turned the wanted angle.
    void turnBy(float angleDeg) {
        if (_hasFailed) return;

        _imu.update();

        float target = _imu.getYawDeg() + angleDeg;
        unsigned long startMs = millis();

        while (fabs(target - _imu.getYawDeg()) > TURN_TOLERANCE_DEG) {
            if (millis() - startMs > TURN_TIMEOUT_MS) {
                fail("Turn timeout");
                return;
            }

            _imu.update();

            float error = target - _imu.getYawDeg();
            int speed = TURN_SPEED;

            // Slow down near the target to reduce overshoot.
            if (fabs(error) < SLOWDOWN_ANGLE_DEG) {
                speed = TURN_SLOW_SPEED;
            }

            if (error > 0) {
                _leftMotor.backward(speed);
                _rightMotor.forward(speed);
            } else {
                _leftMotor.forward(speed);
                _rightMotor.backward(speed);
            }
        }

        stop();
    }

    // CALIBRATION
    const long TICKS_PER_CELL = 1000;          // placeholder: measure 50 cm on the robot
    const float TURN_TOLERANCE_DEG = 2.0;
    const float SLOWDOWN_ANGLE_DEG = 20.0;
    const int TURN_SPEED = 100;
    const int TURN_SLOW_SPEED = 60;            // raise it if the robot stalls just before the target

    // Safety limits: give up if a move or turn takes longer than this
    const unsigned long MOVE_TIMEOUT_MS = 5000;
    const unsigned long TURN_TIMEOUT_MS = 3000;

    // Straight-line correction
    const float HEADING_KP = 2.0;              // lower it if the robot wiggles
    const int HEADING_LIMIT = 25;

    int _moveSpeed = 120;
    bool _hasFailed = false;

    Motor& _leftMotor;
    Motor& _rightMotor;
    Encoder& _leftEncoder;
    Encoder& _rightEncoder;
    Imu& _imu;
};
