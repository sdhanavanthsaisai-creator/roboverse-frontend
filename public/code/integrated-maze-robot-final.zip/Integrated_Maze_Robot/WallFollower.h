#pragma once
#include "Solver.h"

/*
 * =====================================================================================
 * Class: WallFollower (Coder 2 - Friend's Module)
 * Implements the classic Left-Hand Rule exploration algorithm
 * =====================================================================================
 */
class WallFollower : public Solver {
public:
    // Selects the next action prioritizing Left -> Straight -> Right -> Back (U-turn)
    Move chooseMove(bool hasLeftWall, bool hasFrontWall, bool hasRightWall) override {
        if (!hasLeftWall)  return MOVE_LEFT;       // Left is open -> prioritize left turn
        if (!hasFrontWall) return MOVE_STRAIGHT;   // Else if front is open -> drive straight
        if (!hasRightWall) return MOVE_RIGHT;      // Else if right is open -> turn right
        return MOVE_BACK;                          // Trapped on three sides -> U-turn
    }
};
