#pragma once

// Left motor
const int LEFT_MOTOR_DIR_PIN = 18;
const int LEFT_MOTOR_PWM_PIN = 19;

// Right motor
const int RIGHT_MOTOR_DIR_PIN = 23;
const int RIGHT_MOTOR_PWM_PIN = 5;

// Left encoder (pins 34-39 are input-only and have no internal pull-up)
const int LEFT_ENCODER_PIN_A = 34;
const int LEFT_ENCODER_PIN_B = 35;

// Right encoder
const int RIGHT_ENCODER_PIN_A = 36;
const int RIGHT_ENCODER_PIN_B = 39;

// Front ultrasonic sensor (TRIG moved from GPIO12 to GPIO4: GPIO12 is a boot-strapping pin)
const int FRONT_ULTRASONIC_TRIG_PIN = 4;
const int FRONT_ULTRASONIC_ECHO_PIN = 13;   // echo is 5 V: use a voltage divider

// Left ultrasonic sensor
const int LEFT_ULTRASONIC_TRIG_PIN = 14;
const int LEFT_ULTRASONIC_ECHO_PIN = 27;    // voltage divider needed

// Right ultrasonic sensor
const int RIGHT_ULTRASONIC_TRIG_PIN = 25;
const int RIGHT_ULTRASONIC_ECHO_PIN = 26;   // voltage divider needed

// Wall detection: a wall closer than this distance (cm) counts as present.
const float WALL_THRESHOLD_CM = 25.0;

// Mirrored motors and encoders. On a two-wheel robot one side is mirrored.
// After the first wheel test, flip a value if a wheel drives backwards when
// the robot should go forward, or if an encoder counts down while driving forward.
const bool LEFT_MOTOR_REVERSED    = false;
const bool RIGHT_MOTOR_REVERSED   = true;
const bool LEFT_ENCODER_REVERSED  = false;
const bool RIGHT_ENCODER_REVERSED = true;

// Gyro direction: +1.0 if the yaw INCREASES when the robot turns left,
// -1.0 if it DECREASES. One flip fixes both the turns and the straight driving.
const float IMU_YAW_SIGN = 1.0;
