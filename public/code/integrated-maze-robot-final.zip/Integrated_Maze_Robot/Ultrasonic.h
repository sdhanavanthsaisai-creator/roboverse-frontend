#pragma once
#include <Arduino.h>

class Ultrasonic {
private:
    int _trigPin;
    int _echoPin;

public:
    Ultrasonic(int trigPin, int echoPin)
        : _trigPin(trigPin), _echoPin(echoPin) {}

    void begin() {
        pinMode(_trigPin, OUTPUT);
        pinMode(_echoPin, INPUT);
    }

    float getDistanceCm() {
        digitalWrite(_trigPin, LOW);
        delayMicroseconds(2);

        digitalWrite(_trigPin, HIGH);
        delayMicroseconds(10);
        digitalWrite(_trigPin, LOW);

        long durationUs = pulseIn(_echoPin, HIGH, 25000);

        if (durationUs == 0) {
            return 400.0;
        }

        return (durationUs * 0.034) / 2.0;
    }
};
