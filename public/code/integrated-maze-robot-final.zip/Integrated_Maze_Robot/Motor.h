#pragma once
#include <Arduino.h>

class Motor {
private:
    int _pwmPin;
    int _dirPin;
    bool _isReversed;

public:
    Motor(int pwmPin, int dirPin, bool isReversed = false)
        : _pwmPin(pwmPin), _dirPin(dirPin), _isReversed(isReversed) {}

    void begin() {
        pinMode(_pwmPin, OUTPUT);
        pinMode(_dirPin, OUTPUT);
        stop();
    }

    void forward(int speed) {
        digitalWrite(_dirPin, _isReversed ? LOW : HIGH);
        analogWrite(_pwmPin, constrain(speed, 0, 255));
    }

    void backward(int speed) {
        digitalWrite(_dirPin, _isReversed ? HIGH : LOW);
        analogWrite(_pwmPin, constrain(speed, 0, 255));
    }

    void stop() {
        analogWrite(_pwmPin, 0);
    }
};
