#pragma once
#include <Arduino.h>
#include "Robot.h"
#include "Ultrasonic.h"
#include "Solver.h"
#include "PathRecorder.h"
#include "pins.h"

/*
 * =====================================================================================
 * Class: MazeRunner (Run 1: Autonomous Exploration & Goal Discovery)
 * 
 * Logic from teammate's MazeRunner:
 *   - Performs one autonomous step: look, decide, filter real choices, record, move.
 *   - Detects the exit when front sensor reads open space >= 350 cm.
 *   - Automatically simplifies (prunes) the path upon reaching the goal.
 * =====================================================================================
 */
class MazeRunner {
private:
    Robot&        _robot;
    Solver&       _solver;
    PathRecorder& _path;
    Ultrasonic&   _leftSensor;
    Ultrasonic&   _frontSensor;
    Ultrasonic&   _rightSensor;
    bool          _isFinished;

    // CALIBRATION: adjust to match the actual maze wall spacing and sensor readings.
    const float   WALL_DISTANCE_CM = WALL_THRESHOLD_CM;

    // CALIBRATION: distance used to recognize the open goal/exit area.
    const float   GOAL_DISTANCE_CM = 350.0;

    // The goal counts only if 3 front readings in a row agree.
    // One bad reading (no echo gives 400) cannot end the run by mistake.
    bool isGoalConfirmed() {
        for (int i = 0; i < 3; i++) {
            if (_frontSensor.getDistanceCm() < GOAL_DISTANCE_CM) return false;
        }
        return true;
    }

    // A corridor or single corner has only one way to go, so it is not worth saving.
    // Only real junctions (>= 2 open sides) and dead ends (MOVE_BACK) are saved.
    bool isRealChoice(Move move, bool hasLeftWall, bool hasFrontWall, bool hasRightWall) {
        int openSides = 0;
        if (!hasLeftWall)  openSides++;
        if (!hasFrontWall) openSides++;
        if (!hasRightWall) openSides++;
        if (openSides >= 2) return true;        // Junction: a real choice
        if (move == MOVE_BACK) return true;     // Dead end U-turn
        return false;                           // Forced corridor or corner
    }

    // Turns if needed, then drives one 50 cm cell.
    void doMove(Move move) {
        if (move == MOVE_LEFT)  _robot.turnLeft();
        if (move == MOVE_RIGHT) _robot.turnRight();
        if (move == MOVE_BACK)  _robot.turnAround();
        _robot.moveOneCell();
    }

public:
    // Assembles hardware, solver, and path recorder for Run 1 exploration
    MazeRunner(Robot& robot, Solver& solver, PathRecorder& path,
               Ultrasonic& leftSensor, Ultrasonic& frontSensor, Ultrasonic& rightSensor)
        : _robot(robot), _solver(solver), _path(path),
          _leftSensor(leftSensor), _frontSensor(frontSensor), _rightSensor(rightSensor),
          _isFinished(false) {}

    // Returns true once the goal/exit has been reached
    bool isFinished() {
        return _isFinished;
    }

    // Executes one exploration step: call continuously from loop()
    void step() {
        if (_isFinished) return;

        float frontCm = _frontSensor.getDistanceCm();
        if (frontCm >= GOAL_DISTANCE_CM && isGoalConfirmed()) { // Goal/exit detected (3 readings agree).
            _robot.stop();
            _path.simplify();              // Prune all dead ends for Run 2
            _isFinished = true;
            return;
        }

        bool hasLeftWall  = _leftSensor.getDistanceCm()  < WALL_DISTANCE_CM;
        bool hasFrontWall = frontCm                      < WALL_DISTANCE_CM;
        bool hasRightWall = _rightSensor.getDistanceCm() < WALL_DISTANCE_CM;

        Move move = _solver.chooseMove(hasLeftWall, hasFrontWall, hasRightWall);
        if (isRealChoice(move, hasLeftWall, hasFrontWall, hasRightWall)) {
            _path.record(move); // Save only junctions and dead ends
        }
        doMove(move);
    }
};
